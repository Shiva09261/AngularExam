import { Component } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent {
  constructor(private loginservice: LoginService, private router: Router) {}
  islogout() {
    this.loginservice.logout();
    alert('Logout SucessFully !....');
    this.router.navigate(['/login']);
  }
}
