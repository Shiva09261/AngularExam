import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  loginform!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private loginservice: LoginService,
    private router: Router
  ) {
    this.loginform = this.fb.group({
      name: '',
      email: '',
    });
  }

  onSubmit() {
    this.loginservice.login();
    this.router.navigate(['/dashboard']);
  }
}
